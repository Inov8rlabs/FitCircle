-- Standalone service only. Applied after immutable core migrations 001–008.
-- Fresh service databases start without embedded deployment rows. Importing an
-- embedded host needs an explicit audited export/import, never blind conversion.
do $$ begin
  if exists(select 1 from engage.deployment) then
    raise exception 'Embedded deployment data requires an explicit standalone migration';
  end if;
end $$;
alter table engage.deployment drop column singleton;
alter table engage.deployment add primary key(app_id,environment);
create table engage.service_deployment (
  singleton boolean primary key default true check(singleton),
  id uuid not null unique default gen_random_uuid(),
  environment text not null unique check(environment in ('development','test','staging','production')),
  created_at timestamptz not null default now()
);
alter table engage.deployment add foreign key(environment) references engage.service_deployment(environment);
create table engage.tenant_database_roles (
  role_name name primary key,
  app_id text not null, environment text not null,
  created_at timestamptz not null default now(),
  unique(app_id,environment),
  foreign key(app_id,environment) references engage.deployment(app_id,environment)
);
alter table engage.service_deployment enable row level security;
alter table engage.tenant_database_roles enable row level security;
revoke all on engage.service_deployment,engage.tenant_database_roles from public;

-- The actual PostgreSQL login is the authority. SET ROLE, request headers and
-- user-settable GUCs cannot change session_user for a non-superuser login.
create function engage.current_tenant() returns table(app_id text, environment text)
language sql stable security definer set search_path=pg_catalog,pg_temp as $$
  select r.app_id,r.environment from engage.tenant_database_roles r
  where r.role_name=session_user
$$;
revoke all on function engage.current_tenant() from public;
