create table engage.integration_health (
  app_id text not null,environment text not null,received_at timestamptz not null,
  pending integer not null check(pending>=0),parked integer not null check(parked>=0),
  oldest_pending_at timestamptz,change_cursor bigint not null default 0 check(change_cursor>=0),
  bridge_required boolean not null,
  primary key(app_id,environment),foreign key(app_id,environment) references engage.deployment(app_id,environment)
);
