-- Frozen native fanout contracts survive HTTP failures and process restarts.
-- Only target hashes and policy metadata are stored, never message contents.
create table engage.native_reservations (
  app_id text not null, environment text not null, notification_id uuid not null,
  fingerprint text not null, policy jsonb not null, targets jsonb not null,
  expires_at timestamptz not null, closed boolean not null default false,
  primary key(app_id,environment,notification_id),
  foreign key(app_id,environment,notification_id) references engage.host_notifications(app_id,environment,id) on delete cascade
);
