-- App connector identities are verified before these private tenant rows are used.
create table engage.integration_versions (
  app_id text not null, environment text not null, kind text not null,
  entity_key text not null, version bigint not null check(version>0), fingerprint text not null,
  updated_at timestamptz not null,
  primary key(app_id,environment,kind,entity_key),
  foreign key(app_id,environment) references engage.deployment(app_id,environment)
);
create table engage.integration_nonces (
  app_id text not null, environment text not null, nonce uuid not null, expires_at timestamptz not null,
  primary key(app_id,environment,nonce),foreign key(app_id,environment) references engage.deployment(app_id,environment)
);
create index integration_nonces_expiry on engage.integration_nonces(app_id,environment,expires_at);
create table engage.integration_budgets (
  app_id text not null, environment text not null, minute timestamptz not null, requests integer not null,
  primary key(app_id,environment,minute),foreign key(app_id,environment) references engage.deployment(app_id,environment)
);
create table engage.integration_changes (
  app_id text not null, environment text not null, id bigint generated always as identity,
  user_id uuid not null, kind text not null check(kind in ('consent','deleted')), payload jsonb not null,
  created_at timestamptz not null, primary key(app_id,environment,id),
  foreign key(app_id,environment) references engage.deployment(app_id,environment)
);
create index integration_changes_user on engage.integration_changes(app_id,environment,user_id,id);
create table engage.source_campaigns (
  app_id text not null, environment text not null, source_key text not null, name text not null,
  revision bigint not null check(revision>0), bridge_ready boolean not null default false, updated_at timestamptz not null,
  primary key(app_id,environment,source_key),foreign key(app_id,environment) references engage.deployment(app_id,environment)
);
create table engage.integration_devices (
  app_id text not null, environment text not null, id uuid not null, user_id uuid not null, install_id uuid not null,
  platform text not null check(platform in ('ios','android')), token_hash text not null, ciphertext text not null,
  active boolean not null default true, invalidated boolean not null default false, updated_at timestamptz not null,
  primary key(app_id,environment,id), unique(app_id,environment,token_hash),
  foreign key(app_id,environment,user_id) references engage.subjects(app_id,environment,id)
);
create unique index integration_devices_active on engage.integration_devices(app_id,environment,install_id) where active;
create index integration_devices_user on engage.integration_devices(app_id,environment,user_id,install_id);
