-- Engage core v1. Portable: no host-app tables, functions or business triggers.
create schema if not exists engage;
revoke all on schema engage from public;
create table engage.deployment (
  singleton boolean primary key default true check (singleton),
  app_id text not null, environment text not null check (environment in ('development','test','staging','production')),
  created_at timestamptz not null default now(), analytics_epoch bigint not null default 0, unique(app_id, environment)
);
create table engage.subjects (
  app_id text not null, environment text not null, id uuid not null,
  email text, facts jsonb not null default '{}', consent jsonb not null default '{}',
  timezone text not null default 'UTC', locale text not null default 'en', is_test boolean not null default false,
  policy_revision integer not null default 1, deleted_at timestamptz, updated_at timestamptz not null default now(),
  primary key(app_id,environment,id), foreign key(app_id,environment) references engage.deployment(app_id,environment)
);
create table engage.devices (
  app_id text not null, environment text not null, install_id uuid not null, user_id uuid not null,
  platform text not null check(platform in ('ios','android','web')), session jsonb not null,
  token_ref text, last_seen_at timestamptz not null, unbound_at timestamptz,
  primary key(app_id,environment,install_id), foreign key(app_id,environment,user_id) references engage.subjects(app_id,environment,id)
);
create unique index devices_token on engage.devices(app_id,environment,token_ref) where token_ref is not null and unbound_at is null;
create index devices_user on engage.devices(app_id,environment,user_id,last_seen_at desc,install_id) where unbound_at is null;
create index devices_stale_token on engage.devices(app_id,environment,last_seen_at,install_id) where token_ref is not null;
-- Permanent provider rejection survives session refresh and host token resolver mistakes.
create table engage.invalidated_tokens (
  app_id text not null, environment text not null, id uuid not null, user_id uuid not null, install_id uuid not null,
  token_hash text not null, invalidated_at timestamptz not null,
  primary key(app_id,environment,id), unique(app_id,environment,token_hash),
  foreign key(app_id,environment,user_id) references engage.subjects(app_id,environment,id)
);
create table engage.web_push_subscriptions (
  app_id text not null, environment text not null, id uuid not null, user_id uuid not null, install_id uuid not null,
  endpoint_hash text not null, binding_id text not null, ciphertext text not null, active boolean not null,
  created_at timestamptz not null, expires_at timestamptz,
  primary key(app_id,environment,id), unique(app_id,environment,install_id), unique(app_id,environment,endpoint_hash),
  foreign key(app_id,environment,install_id) references engage.devices(app_id,environment,install_id),
  foreign key(app_id,environment,user_id) references engage.subjects(app_id,environment,id)
);
create table engage.campaigns (
  app_id text not null, environment text not null, id uuid not null, key text not null,
  revision integer not null default 1, published_version integer not null default 0,
  status text not null default 'draft' check(status in ('draft','scheduled','live','paused','completed','archived')),
  draft jsonb not null, created_by text not null, updated_by text not null,
  created_at timestamptz not null, updated_at timestamptz not null,
  queue_touched_at timestamptz not null default '-infinity',
  primary key(app_id,environment,id), unique(app_id,environment,key),
  foreign key(app_id,environment) references engage.deployment(app_id,environment)
);
create table engage.versions (
  app_id text not null, environment text not null, campaign_id uuid not null, version integer not null,
  snapshot jsonb not null, launched_at timestamptz not null, actor text not null, admitted_users integer not null default 0,
  primary key(app_id,environment,campaign_id,version), foreign key(app_id,environment,campaign_id) references engage.campaigns(app_id,environment,id)
);
create table engage.admissions (
  app_id text not null, environment text not null, campaign_id uuid not null, version integer not null, user_id uuid not null,
  admitted_at timestamptz not null,
  primary key(app_id,environment,campaign_id,version,user_id),
  foreign key(app_id,environment,campaign_id,version) references engage.versions(app_id,environment,campaign_id,version),
  foreign key(app_id,environment,user_id) references engage.subjects(app_id,environment,id)
);
create table engage.segments (
  app_id text not null, environment text not null, id uuid not null, name text not null,
  revision integer not null default 1, audience jsonb not null, materialized boolean not null default false,
  updated_at timestamptz not null, primary key(app_id,environment,id), foreign key(app_id,environment) references engage.deployment(app_id,environment)
);
create table engage.segment_members (
  app_id text not null, environment text not null, segment_id uuid not null, user_id uuid not null,
  entered_at timestamptz not null, generation bigint not null,
  primary key(app_id,environment,segment_id,user_id),
  foreign key(app_id,environment,segment_id) references engage.segments(app_id,environment,id),
  foreign key(app_id,environment,user_id) references engage.subjects(app_id,environment,id)
);
create table engage.dry_runs (
  app_id text not null, environment text not null, id uuid not null, campaign_id uuid not null,
  revision integer not null, digest text not null, report jsonb not null, created_at timestamptz not null,
  primary key(app_id,environment,id), foreign key(app_id,environment,campaign_id) references engage.campaigns(app_id,environment,id)
);
create table engage.controls (
  app_id text not null, environment text not null, scope text not null, campaign_id uuid,
  platform text check(platform in ('ios','android','web')), channel text check(channel in ('push','web_push','email','in_app','feed','placement')),
  paused boolean not null, revision integer not null, reason text not null, actor text not null, updated_at timestamptz not null,
  primary key(app_id,environment,scope), foreign key(app_id,environment) references engage.deployment(app_id,environment),
  foreign key(app_id,environment,campaign_id) references engage.campaigns(app_id,environment,id)
);
create table engage.assignments (
  app_id text not null, environment text not null, campaign_id uuid not null, user_id uuid not null,
  variant_id text, in_control boolean not null, assigned_at timestamptz not null,
  primary key(app_id,environment,campaign_id,user_id),
  foreign key(app_id,environment,campaign_id) references engage.campaigns(app_id,environment,id),
  foreign key(app_id,environment,user_id) references engage.subjects(app_id,environment,id),
  check ((in_control and variant_id is null) or (not in_control and variant_id is not null))
);
create table engage.dispatches (
  app_id text not null, environment text not null, id uuid not null, campaign_id uuid not null, version integer not null,
  occurrence_key text not null, scope text not null check(scope in ('broadcast','recipient','journey')),
  recipient_id uuid, event_id uuid, message_id uuid, run_at timestamptz not null, expires_at timestamptz not null,
  status text not null default 'queued' check(status in ('queued','planned','completed','cancelled')),
  created_at timestamptz not null, primary key(app_id,environment,id), unique(app_id,environment,campaign_id,occurrence_key),
  foreign key(app_id,environment,campaign_id,version) references engage.versions(app_id,environment,campaign_id,version),
  foreign key(app_id,environment,recipient_id) references engage.subjects(app_id,environment,id),
  check((scope='broadcast' and recipient_id is null) or (scope in ('recipient','journey') and recipient_id is not null))
);
create index dispatches_due on engage.dispatches(app_id,environment,run_at) where status='queued';
create table engage.recipients (
  app_id text not null, environment text not null, dispatch_id uuid not null, user_id uuid not null,
  variant_id text, in_control boolean not null, eligible_platforms text[] not null, enrolled_at timestamptz not null,
  primary key(app_id,environment,dispatch_id,user_id), foreign key(app_id,environment,dispatch_id) references engage.dispatches(app_id,environment,id),
  foreign key(app_id,environment,user_id) references engage.subjects(app_id,environment,id)
);
create index recipients_subject_time on engage.recipients(app_id,environment,user_id,enrolled_at);
create table engage.sends (
  app_id text not null, environment text not null, id uuid not null, dispatch_id uuid not null, campaign_id uuid not null,
  version integer not null, message_id uuid not null, user_id uuid not null, variant_id text not null,
  channel text not null check(channel in ('push','email','web_push')),
  status text not null default 'queued' check(status in ('queued','leased','dispatching','accepted','retry_wait','suppressed','skipped','failed_permanent','outcome_unknown','cancelled','expired')),
  reason text, due_at timestamptz not null, expires_at timestamptz not null,
  lease_owner uuid, lease_until timestamptz, fence bigint not null default 0, attempts integer not null default 0,
  created_at timestamptz not null, accepted_at timestamptz, updated_at timestamptz not null,
  primary key(app_id,environment,id), unique(app_id,environment,dispatch_id,message_id,user_id),
  foreign key(app_id,environment,campaign_id,version) references engage.versions(app_id,environment,campaign_id,version),
  foreign key(app_id,environment,dispatch_id,user_id) references engage.recipients(app_id,environment,dispatch_id,user_id)
);
create index sends_due on engage.sends(app_id,environment,due_at) where status in ('queued','retry_wait','leased');
create index sends_campaign_due on engage.sends(app_id,environment,campaign_id,due_at,id) where status in ('queued','retry_wait','leased');
create index sends_user on engage.sends(app_id,environment,user_id,created_at);
create index sends_retention on engage.sends(app_id,environment,created_at,id);
create table engage.attempts (
  app_id text not null, environment text not null, id uuid not null, send_id uuid not null, install_id uuid,
  platform text not null check(platform in ('ios','android','web','not_applicable')), target_key text not null,
  status text not null check(status in ('dispatching','accepted','retry_wait','failed_permanent','outcome_unknown','cancelled')),
  payload jsonb not null, payload_hash text not null, idempotency_key text not null,
  provider_id text, reason text, started_at timestamptz not null, finished_at timestamptz,
  primary key(app_id,environment,id), unique(app_id,environment,send_id,target_key),
  foreign key(app_id,environment,send_id) references engage.sends(app_id,environment,id),
  foreign key(app_id,environment,install_id) references engage.devices(app_id,environment,install_id)
);
create table engage.cap_reservations (
  app_id text not null, environment text not null, send_id uuid not null, user_id uuid not null, channel text not null,
  category text not null, counts_global boolean not null default true, reserved_at timestamptz not null, state text not null check(state in ('reserved','accepted','unknown')),
  primary key(app_id,environment,send_id), foreign key(app_id,environment,send_id) references engage.sends(app_id,environment,id),
  foreign key(app_id,environment,user_id) references engage.subjects(app_id,environment,id)
);
-- One durable handoff intent per physical target retry. Payload stays on the
-- immutable target record; history never contains a second copy of PII.
create table engage.handoffs (
  app_id text not null, environment text not null, id uuid not null,
  attempt_id uuid not null, fence bigint not null, started_at timestamptz not null,
  finished_at timestamptz, status text not null default 'dispatching'
    check(status in ('dispatching','accepted','retry_wait','failed_permanent','outcome_unknown')),
  reason text, provider_id text,
  primary key(app_id,environment,id),
  foreign key(app_id,environment,attempt_id) references engage.attempts(app_id,environment,id) on delete cascade
);
create index handoffs_attempt on engage.handoffs(app_id,environment,attempt_id,started_at);
-- Store only verified, owned feedback. Never persist raw webhook bodies or addresses.
create table engage.provider_receipts (
  app_id text not null, environment text not null, id uuid not null,
  provider text not null check(provider='resend'), event_id text not null, fingerprint text not null,
  attempt_id uuid not null, provider_id text not null,
  type text not null check(type in ('sent','delivered','delivery_delayed','bounced','complained','opened','clicked','failed','suppressed')),
  occurred_at timestamptz not null, received_at timestamptz not null, reconciled_at timestamptz,
  resolution text not null default 'pending' check(resolution in ('pending','applied','conflict')),
  primary key(app_id,environment,id), unique(app_id,environment,provider,event_id),
  foreign key(app_id,environment,attempt_id) references engage.attempts(app_id,environment,id) on delete cascade
);
create index provider_receipts_pending on engage.provider_receipts(app_id,environment,received_at) where reconciled_at is null;
create index provider_receipts_attempt on engage.provider_receipts(app_id,environment,attempt_id,type);
create table engage.email_suppressions (
  app_id text not null, environment text not null, id uuid not null, user_id uuid not null,
  address_hash text not null, reason text not null check(reason in ('bounced','complained','suppressed')),
  created_at timestamptz not null,
  primary key(app_id,environment,id), unique(app_id,environment,user_id,address_hash),
  foreign key(app_id,environment,user_id) references engage.subjects(app_id,environment,id)
);
create unique index handoffs_active on engage.handoffs(app_id,environment,attempt_id) where finished_at is null;
create index cap_user_time on engage.cap_reservations(app_id,environment,user_id,reserved_at);
-- Host notifications and Engage campaigns share the subject lock and cap ledger.
-- Key hashes avoid storing domain event contents; uncertain/crashed sends remain charged.
create table engage.host_notifications (
  app_id text not null, environment text not null, id uuid not null, user_id uuid not null,
  key_hash text not null, channel text not null check(channel in ('push','web_push','email')),
  category text not null check(category in ('marketing','lifecycle','transactional')),
  counts_global boolean not null, reserved_at timestamptz not null, finished_at timestamptz,
  state text not null check(state in ('reserved','accepted','unknown','failed_permanent','suppressed')),
  reason text, primary key(app_id,environment,id), unique(app_id,environment,user_id,key_hash),
  foreign key(app_id,environment,user_id) references engage.subjects(app_id,environment,id)
);
create index host_notification_cap on engage.host_notifications(app_id,environment,user_id,reserved_at) where counts_global=true;
create table engage.rate_buckets (
  app_id text not null, environment text not null, channel text not null, minute timestamptz not null, used integer not null,
  primary key(app_id,environment,channel,minute), foreign key(app_id,environment) references engage.deployment(app_id,environment)
);
create table engage.receipts (
  app_id text not null, environment text not null, id uuid not null, campaign_id uuid not null, version integer not null,
  message_id uuid not null, dispatch_id uuid not null, user_id uuid not null, install_id uuid not null, variant_id text not null,
  surface text not null, platform text not null, delivered_at timestamptz not null, expires_at timestamptz not null,
  preview boolean not null default false, impression_at timestamptz, clicked_at timestamptz, dismissed_at timestamptz,
  primary key(app_id,environment,id), foreign key(app_id,environment,campaign_id,version) references engage.versions(app_id,environment,campaign_id,version),
  foreign key(app_id,environment,dispatch_id,user_id) references engage.recipients(app_id,environment,dispatch_id,user_id),
  foreign key(app_id,environment,install_id) references engage.devices(app_id,environment,install_id)
);
create index receipts_user on engage.receipts(app_id,environment,user_id,message_id,delivered_at);
create table engage.iam_permits (
  app_id text not null, environment text not null, id uuid not null, receipt_id uuid not null,
  user_id uuid not null, install_id uuid not null, session_id uuid not null,
  granted_at timestamptz not null, expires_at timestamptz not null, displayed_at timestamptz,
  primary key(app_id,environment,id), unique(app_id,environment,receipt_id),
  foreign key(app_id,environment,receipt_id) references engage.receipts(app_id,environment,id),
  foreign key(app_id,environment,user_id) references engage.subjects(app_id,environment,id),
  foreign key(app_id,environment,install_id) references engage.devices(app_id,environment,install_id)
);
create index permits_user on engage.iam_permits(app_id,environment,user_id,granted_at);
-- Minimal replay/provenance ledger survives raw-event expiry. Hashes are still
-- account-linked data and are erased with the subject, never exported to admins.
create table engage.event_keys (
  app_id text not null, environment text not null, id uuid not null, user_id uuid not null,
  source text not null check(source in ('client','server','provider')), key_hash text not null,
  fingerprint text not null, created_at timestamptz not null,
  primary key(app_id,environment,source,key_hash), unique(app_id,environment,id),
  foreign key(app_id,environment,user_id) references engage.subjects(app_id,environment,id)
);
create table engage.events (
  app_id text not null, environment text not null, id uuid not null, user_id uuid not null, install_id uuid,
  source text not null check(source in ('client','server','provider')), dedupe_key text not null,
  type text not null, name text, props jsonb not null default '{}', receipt_id uuid, send_id uuid,
  platform text, occurred_at timestamptz not null, received_at timestamptz not null,
  processed_at timestamptz, primary key(app_id,environment,id), unique(app_id,environment,source,dedupe_key),
  foreign key(app_id,environment,user_id) references engage.subjects(app_id,environment,id),
  foreign key(app_id,environment,receipt_id) references engage.receipts(app_id,environment,id),
  foreign key(app_id,environment,send_id) references engage.sends(app_id,environment,id)
);
create index events_subject on engage.events(app_id,environment,user_id,name,occurred_at);
create index events_send on engage.events(app_id,environment,send_id) where send_id is not null;
create index events_unprocessed on engage.events(app_id,environment,received_at) where processed_at is null;
create index events_processed on engage.events(app_id,environment,received_at desc) where processed_at is not null;
create index events_retention on engage.events(app_id,environment,received_at,id) where processed_at is not null;
-- Compact delivery evidence, without properties or destinations, keeps exact
-- historical open counts after raw ingestion rows expire.
create table engage.push_open_facts (
  app_id text not null, environment text not null, event_id uuid not null,
  user_id uuid not null, send_id uuid not null, dispatch_id uuid not null, install_id uuid not null,
  platform text not null, occurred_at timestamptz not null,
  primary key(app_id,environment,event_id),
  foreign key(app_id,environment,user_id) references engage.subjects(app_id,environment,id),
  foreign key(app_id,environment,dispatch_id,user_id) references engage.recipients(app_id,environment,dispatch_id,user_id)
);
create index push_open_facts_send on engage.push_open_facts(app_id,environment,send_id,occurred_at);
create table engage.conversions (
  app_id text not null, environment text not null, campaign_id uuid not null, user_id uuid not null, event_id uuid not null,
  version integer not null, goal text not null, variant_id text, in_control boolean not null, platform text, occurred_at timestamptz not null,
  dispatch_id uuid not null, enrolled_at timestamptz not null, eligible_platforms text[] not null,
  -- event_id is stable provenance; raw ingestion data expires after 90 days.
  -- Events.attribute owns this write and verifies the source before insertion.
  primary key(app_id,environment,campaign_id,user_id,goal),
  foreign key(app_id,environment,campaign_id,version) references engage.versions(app_id,environment,campaign_id,version),
  foreign key(app_id,environment,campaign_id,user_id) references engage.assignments(app_id,environment,campaign_id,user_id),
  foreign key(app_id,environment,dispatch_id,user_id) references engage.recipients(app_id,environment,dispatch_id,user_id)
);
create table engage.journeys (
  app_id text not null, environment text not null, id uuid not null, campaign_id uuid not null, version integer not null,
  user_id uuid not null, step_id text not null, due_at timestamptz not null, entered_at timestamptz not null,
  exited_at timestamptz, exit_reason text, context jsonb not null default '{}',
  primary key(app_id,environment,id), foreign key(app_id,environment,campaign_id,version) references engage.versions(app_id,environment,campaign_id,version),
  foreign key(app_id,environment,user_id) references engage.subjects(app_id,environment,id)
);
create unique index journey_active on engage.journeys(app_id,environment,campaign_id,user_id) where exited_at is null;
create index journey_due on engage.journeys(app_id,environment,due_at) where exited_at is null;
create table engage.audit (
  app_id text not null, environment text not null, id bigint generated always as identity,
  actor text not null, action text not null, entity_id text, details jsonb not null default '{}', created_at timestamptz not null,
  primary key(app_id,environment,id), foreign key(app_id,environment) references engage.deployment(app_id,environment)
);
create table engage.assets (
  app_id text not null, environment text not null, id uuid not null, name text not null, sha256 text not null,
  mime text not null, bytes integer not null, width integer not null, height integer not null, url text not null,
  created_at timestamptz not null, archived_at timestamptz,
  primary key(app_id,environment,id), unique(app_id,environment,sha256), foreign key(app_id,environment) references engage.deployment(app_id,environment)
);
-- Preview authorization and telemetry are deliberately separate from production delivery.
create table engage.test_enrollments (
  app_id text not null, environment text not null, id uuid not null, code_hash text not null,
  actor text not null, label text not null, created_at timestamptz not null, expires_at timestamptz not null,
  claimed_at timestamptz, user_id uuid, install_id uuid,
  primary key(app_id,environment,id), unique(app_id,environment,code_hash),
  foreign key(app_id,environment) references engage.deployment(app_id,environment)
);
create index test_enrollment_actor on engage.test_enrollments(app_id,environment,actor,created_at);
create table engage.test_devices (
  app_id text not null, environment text not null, install_id uuid not null, user_id uuid not null,
  actor text not null, label text not null, expires_at timestamptz not null, acknowledged_at timestamptz not null,
  primary key(app_id,environment,install_id),
  foreign key(app_id,environment,user_id) references engage.subjects(app_id,environment,id),
  foreign key(app_id,environment,install_id) references engage.devices(app_id,environment,install_id)
);
create table engage.preview_grants (
  app_id text not null, environment text not null, id uuid not null, campaign_id uuid not null, install_id uuid not null,
  user_id uuid not null, actor text not null, draft jsonb not null, item jsonb not null, revision integer not null,
  request_id uuid not null, request_fingerprint text not null,
  token_ref text, email text, email_fields jsonb not null default '{}', surface text not null, state text not null check(state in ('pending','dispatching','accepted','failed','unknown','revoked')),
  expires_at timestamptz not null, created_at timestamptz not null, served_at timestamptz, received_at timestamptz, displayed_at timestamptz,
  clicked_at timestamptz, dismissed_at timestamptz, started_at timestamptz, finished_at timestamptz,
  permit_id uuid, session_id uuid, permit_at timestamptz, permit_expires_at timestamptz, reason text,
  primary key(app_id,environment,id),
  foreign key(app_id,environment,user_id) references engage.subjects(app_id,environment,id),
  foreign key(app_id,environment,campaign_id) references engage.campaigns(app_id,environment,id),
  foreign key(app_id,environment,install_id) references engage.devices(app_id,environment,install_id)
);
create unique index preview_request on engage.preview_grants(app_id,environment,actor,request_id);
create index preview_recipient on engage.preview_grants(app_id,environment,user_id,install_id,expires_at);
create index preview_actor on engage.preview_grants(app_id,environment,actor,created_at);
create table engage.preview_events (
  app_id text not null, environment text not null, user_id uuid not null, install_id uuid not null,
  client_event_id uuid not null, grant_id uuid not null, fingerprint text not null, type text not null, occurred_at timestamptz not null,
  primary key(app_id,environment,user_id,install_id,client_event_id),
  foreign key(app_id,environment,grant_id) references engage.preview_grants(app_id,environment,id) on delete cascade
);
-- Compact account-linked reporting/occurrence facts replace terminal raw sends
-- after 400 days. No personalized content, email address, token, signing key,
-- provider response body or transport payload survives in these tables.
create table engage.send_facts (
  app_id text not null, environment text not null, id uuid not null,
  dispatch_id uuid not null, campaign_id uuid not null, version integer not null,
  message_id uuid not null, user_id uuid not null, variant_id text not null,
  channel text not null, status text not null, reason text,
  due_at timestamptz not null, expires_at timestamptz not null, created_at timestamptz not null,
  accepted_at timestamptz, updated_at timestamptz not null, archived_at timestamptz not null,
  cap_reserved_at timestamptz, cap_state text, counts_global boolean,
  primary key(app_id,environment,id), unique(app_id,environment,dispatch_id,message_id,user_id),
  foreign key(app_id,environment,campaign_id,version) references engage.versions(app_id,environment,campaign_id,version),
  foreign key(app_id,environment,dispatch_id,user_id) references engage.recipients(app_id,environment,dispatch_id,user_id)
);
create index send_facts_time on engage.send_facts(app_id,environment,created_at);
create index send_facts_subject on engage.send_facts(app_id,environment,user_id,campaign_id);
create index send_facts_campaign_time on engage.send_facts(app_id,environment,campaign_id,created_at);
create table engage.target_facts (
  app_id text not null, environment text not null, id uuid not null, send_id uuid not null,
  install_id uuid, platform text not null, status text not null, reason text,
  started_at timestamptz not null, finished_at timestamptz, handoff_count integer not null,
  primary key(app_id,environment,id),
  foreign key(app_id,environment,send_id) references engage.send_facts(app_id,environment,id) on delete cascade
);
create index target_facts_send on engage.target_facts(app_id,environment,send_id);
create index target_facts_unknown on engage.target_facts(app_id,environment,id) where status='outcome_unknown';
create table engage.feedback_facts (
  app_id text not null, environment text not null, id uuid not null, attempt_id uuid not null,
  type text not null, resolution text not null, occurred_at timestamptz not null, received_at timestamptz not null,
  primary key(app_id,environment,id),
  foreign key(app_id,environment,attempt_id) references engage.target_facts(app_id,environment,id) on delete cascade
);
create index feedback_facts_target on engage.feedback_facts(app_id,environment,attempt_id);

-- Invoker security preserves RLS when a non-owner is explicitly granted view access.
create view engage.reporting_sends with (security_invoker=true) as
  select app_id,environment,id,dispatch_id,campaign_id,version,message_id,user_id,variant_id,channel,status,reason,due_at,expires_at,created_at,accepted_at,updated_at from engage.sends
  union all select app_id,environment,id,dispatch_id,campaign_id,version,message_id,user_id,variant_id,channel,status,reason,due_at,expires_at,created_at,accepted_at,updated_at from engage.send_facts;
create view engage.reporting_targets with (security_invoker=true) as
  select app_id,environment,id,send_id,install_id,platform,status,reason,started_at,finished_at from engage.attempts
  union all select app_id,environment,id,send_id,install_id,platform,status,reason,started_at,finished_at from engage.target_facts;
create view engage.reporting_handoff_counts with (security_invoker=true) as
  select app_id,environment,attempt_id,1::integer handoff_count from engage.handoffs
  union all select app_id,environment,id as attempt_id,handoff_count from engage.target_facts;
create view engage.reporting_feedback with (security_invoker=true) as
  select app_id,environment,id,attempt_id,type,resolution,occurred_at,received_at from engage.provider_receipts
  union all select app_id,environment,id,attempt_id,type,resolution,occurred_at,received_at from engage.feedback_facts;
create view engage.reporting_cap_reservations with (security_invoker=true) as
  select app_id,environment,send_id,user_id,channel,category,reserved_at,state,counts_global from engage.cap_reservations
  union all select s.app_id,s.environment,s.id,s.user_id,s.channel,v.snapshot->>'category',s.cap_reserved_at,s.cap_state,s.counts_global
  from engage.send_facts s join engage.versions v on v.app_id=s.app_id and v.environment=s.environment and v.campaign_id=s.campaign_id and v.version=s.version where s.cap_reserved_at is not null;
revoke all on engage.reporting_sends,engage.reporting_targets,engage.reporting_handoff_counts,engage.reporting_feedback,engage.reporting_cap_reservations from public;

create table engage.health (
  app_id text not null, environment text not null, component text not null, observed_at timestamptz not null, details jsonb not null,
  primary key(app_id,environment,component), foreign key(app_id,environment) references engage.deployment(app_id,environment)
);
-- Daily aggregate snapshots contain no person/installation identifiers. Epoch
-- fencing prevents a report started before erasure from repopulating a current
-- cache after erasure. Range-level uniques still come from Metrics.read.
create table engage.stats_daily (
  app_id text not null, environment text not null, day date not null,
  filter_hash text not null, dimensions jsonb not null, counts jsonb not null,
  epoch bigint not null, source_observed_at timestamptz not null,
  primary key(app_id,environment,day,filter_hash),
  foreign key(app_id,environment) references engage.deployment(app_id,environment)
);
create table engage.admin_nonces (
  app_id text not null, environment text not null, nonce uuid not null, expires_at timestamptz not null,
  primary key(app_id,environment,nonce), foreign key(app_id,environment) references engage.deployment(app_id,environment)
);
create index admin_nonce_expiry on engage.admin_nonces(app_id,environment,expires_at);
create table engage.request_buckets (
  app_id text not null, environment text not null, user_id uuid not null, operation text not null,
  minute timestamptz not null, used integer not null,
  primary key(app_id,environment,user_id,operation,minute),
  foreign key(app_id,environment,user_id) references engage.subjects(app_id,environment,id)
);
revoke all on all tables in schema engage from public;
revoke all on all sequences in schema engage from public;
