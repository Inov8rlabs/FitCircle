-- Operator evidence can close an unknown result without refunding its original cap window.
alter table engage.host_notifications add column cap_charged boolean not null default false;
-- Original transport observation stays distinct from later signed/operator evidence.
alter table engage.host_handoffs add column transport_state text check(transport_state in ('accepted','unknown','failed_permanent'));
