-- Freeze the authorized address as a hash so a late bounce cannot suppress a new address.
alter table engage.host_handoffs add column address_hash text;
alter table engage.host_handoffs add column provider_id text;
alter table engage.host_handoffs add column provider_conflict boolean not null default false;
create table engage.host_provider_receipts (
  app_id text not null, environment text not null, id uuid not null,
  provider text not null check(provider='resend'), event_id text not null,
  fingerprint text not null, handoff_id uuid not null, provider_id text not null,
  type text not null check(type in ('sent','delivered','delivery_delayed','bounced','complained','opened','clicked','failed','suppressed')),
  occurred_at timestamptz not null, received_at timestamptz not null,
  resolution text not null default 'pending' check(resolution in ('pending','applied','conflict')),
  reconciled_at timestamptz,
  primary key(app_id,environment,id),
  unique(app_id,environment,provider,event_id),
  foreign key(app_id,environment,handoff_id) references engage.host_handoffs(app_id,environment,id) on delete cascade
);
create index host_provider_receipts_pending on engage.host_provider_receipts(app_id,environment,received_at,id) where reconciled_at is null;
