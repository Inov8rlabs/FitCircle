-- Exact-target legacy handoffs share the deployment policy gate and channel rates.
-- No recipient address, token, content, or provider credential is retained here.
create table engage.host_handoffs (
  app_id text not null, environment text not null, id uuid not null,
  notification_id uuid not null, target_hash text not null,
  platform text not null check(platform in ('ios','android','web','not_applicable')),
  state text not null check(state in ('started','accepted','unknown','failed_permanent','suppressed')),
  reason text, started_at timestamptz not null, finished_at timestamptz,
  primary key(app_id,environment,id),
  unique(app_id,environment,notification_id,target_hash),
  foreign key(app_id,environment,notification_id) references engage.host_notifications(app_id,environment,id) on delete cascade
);
create index host_handoffs_open on engage.host_handoffs(app_id,environment,started_at) where state in ('started','unknown');
