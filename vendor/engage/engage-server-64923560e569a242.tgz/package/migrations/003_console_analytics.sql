-- First-party console usage only. No content, URL, recipient, email or actor is stored in events.
create table engage.console_events (
  app_id text not null, environment text not null, id uuid not null, session_id uuid not null,
  event text not null check(event in ('workspace_view','editor_open','campaign_save','dry_run','launch','test_send','control_change','metrics_view','usage_view')),
  outcome text not null check(outcome in ('success','error')),
  duration_ms integer not null check(duration_ms between 0 and 300000),
  role text not null check(role in ('viewer','editor','admin')), received_at timestamptz not null,
  primary key(app_id,environment,id),
  foreign key(app_id,environment) references engage.deployment(app_id,environment)
);
create index console_events_time on engage.console_events(app_id,environment,received_at);
create table engage.console_budgets (
  app_id text not null, environment text not null, actor_hash text not null,
  minute timestamptz not null, used integer not null,
  primary key(app_id,environment,actor_hash,minute),
  foreign key(app_id,environment) references engage.deployment(app_id,environment)
);
