-- Agent credentials never carry the host's administrative signing key.
create table engage.agent_credentials (
  app_id text not null, environment text not null, id uuid not null,
  name text not null, token_hash text not null,
  role text not null check(role in ('viewer','editor','admin')),
  created_by text not null, created_at timestamptz not null,
  expires_at timestamptz not null, revoked_at timestamptz, last_used_at timestamptz,
  primary key(app_id,environment,id),
  foreign key(app_id,environment) references engage.deployment(app_id,environment)
);
create table engage.agent_budgets (
  app_id text not null, environment text not null, credential_id uuid not null,
  minute timestamptz not null, requests integer not null, mutations integer not null,
  primary key(app_id,environment,credential_id,minute),
  foreign key(app_id,environment,credential_id) references engage.agent_credentials(app_id,environment,id)
);
