-- Independent host/Engage campaigns coexist. Only explicitly linked campaigns
-- take part in a handover; unmapped host campaigns keep their original owner.
create table engage.campaign_ownership (
  app_id text not null, environment text not null, source_key text not null,
  campaign_id uuid not null, owner text not null default 'host' check(owner in ('host','paused','engage')),
  previous_owner text not null default 'host' check(previous_owner in ('host','engage')),
  revision integer not null default 1 check(revision > 0),
  created_at timestamptz not null, updated_at timestamptz not null,
  primary key(app_id,environment,source_key), unique(app_id,environment,campaign_id),
  foreign key(app_id,environment,campaign_id) references engage.campaigns(app_id,environment,id)
);
alter table engage.campaign_ownership enable row level security;
revoke all on engage.campaign_ownership from public;
alter table engage.host_notifications add column source_campaign_key text;
-- Imported cap history is deliberately conservative about old outcomes, but is
-- not a live handoff to drain. Preserve its cap/dedupe charge independently.
alter table engage.host_notifications add column imported_history boolean not null default false;
update engage.host_notifications set imported_history=true where reason='host_history_import';
create index host_notifications_campaign on engage.host_notifications(app_id,environment,source_campaign_key,state);
