-- Draft authoring does not imply permission to operate live delivery.
alter table engage.agent_credentials add column allow_live_actions boolean not null default false;
