/* Generated from protocol/src/schemas.ts. Do not edit. */

export type _Schema0 = string;
/**
 * @minItems 1
 * @maxItems 3
 */
export type _Schema1 = [_Schema2] | [_Schema2, _Schema2] | [_Schema2, _Schema2, _Schema2];
export type _Schema2 = "ios" | "android" | "web";
export type Audience =
  | {
      field: string;
      op:
        | "eq"
        | "neq"
        | "in"
        | "not_in"
        | "gt"
        | "gte"
        | "lt"
        | "lte"
        | "between"
        | "exists"
        | "not_exists"
        | "contains"
        | "version_gte"
        | "version_lt"
        | "version_between"
        | "within_last"
        | "not_within_last"
        | "count_gte"
        | "count_lte";
      value?: string | number | boolean | null | _Schema4[];
      event?: {
        name: _Schema0;
        window_seconds: number;
        props: _Schema5;
      };
    }
  | {
      /**
       * @maxItems 50
       */
      all: Audience1[];
    }
  | {
      /**
       * @maxItems 50
       */
      any: Audience1[];
    }
  | {
      not: Audience1;
    }
  | {
      device: {
        scope: "any_device" | "latest_device";
        where: Audience1;
      };
    };
export type _Schema4 = string | number;
export type PropertyValue = string | number | boolean | null;
export type Audience1 =
  | {
      field: string;
      op:
        | "eq"
        | "neq"
        | "in"
        | "not_in"
        | "gt"
        | "gte"
        | "lt"
        | "lte"
        | "between"
        | "exists"
        | "not_exists"
        | "contains"
        | "version_gte"
        | "version_lt"
        | "version_between"
        | "within_last"
        | "not_within_last"
        | "count_gte"
        | "count_lte";
      value?: string | number | boolean | null | _Schema4[];
      event?: {
        name: _Schema0;
        window_seconds: number;
        props: _Schema5;
      };
    }
  | {
      /**
       * @maxItems 50
       */
      all: Audience1[];
    }
  | {
      /**
       * @maxItems 50
       */
      any: Audience1[];
    }
  | {
      not: Audience1;
    }
  | {
      device: {
        scope: "any_device" | "latest_device";
        where: Audience1;
      };
    };
export type _Schema6 = string;
export type _Schema7 = number;
export type Action =
  | {
      type: "open_screen";
      screen: _Schema0;
      params?: _Schema51;
    }
  | {
      type: "open_url";
      url: string;
    }
  | {
      type: "paywall";
      context: _Schema0;
    }
  | {
      type: "experience";
      slug: _Schema0;
    }
  | {
      type: "join_campaign";
      slug: _Schema0;
    }
  | {
      type: "fitzy";
      prompt?: string;
    }
  | {
      type: "dismiss";
    }
  | {
      type: "invite";
    }
  | {
      type: "start_circle";
    }
  | {
      type: "log_water";
    }
  | {
      type: "enable_notifications";
    };
export type _Schema14 =
  | {
      id: _Schema0;
      type: "message";
      message_id: _Schema6;
      next: _Schema0;
      timeout_hours: number;
    }
  | {
      id: _Schema0;
      type: "delay";
      seconds: number;
      next: _Schema0;
    }
  | {
      id: _Schema0;
      type: "branch";
      condition: Audience1;
      yes: _Schema0;
      no: _Schema0;
    }
  | {
      id: _Schema0;
      type: "wait_until";
      condition: Audience1;
      timeout_seconds: number;
      matched: _Schema0;
      timed_out: _Schema0;
    }
  | {
      id: _Schema0;
      type: "split";
      /**
       * @minItems 2
       * @maxItems 8
       */
      arms:
        | [_Schema15, _Schema15]
        | [_Schema15, _Schema15, _Schema15]
        | [_Schema15, _Schema15, _Schema15, _Schema15]
        | [_Schema15, _Schema15, _Schema15, _Schema15, _Schema15]
        | [_Schema15, _Schema15, _Schema15, _Schema15, _Schema15, _Schema15]
        | [_Schema15, _Schema15, _Schema15, _Schema15, _Schema15, _Schema15, _Schema15]
        | [_Schema15, _Schema15, _Schema15, _Schema15, _Schema15, _Schema15, _Schema15, _Schema15];
    }
  | {
      id: _Schema0;
      type: "exit";
    };
export type _Schema16 =
  | string
  | number
  | boolean
  | null
  | _Schema16[]
  | {
      [k: string]: _Schema16;
    };

export interface CampaignDraft {
  key: _Schema0;
  name: string;
  description: string;
  /**
   * @maxItems 20
   */
  tags:
    | []
    | [_Schema0]
    | [_Schema0, _Schema0]
    | [_Schema0, _Schema0, _Schema0]
    | [_Schema0, _Schema0, _Schema0, _Schema0]
    | [_Schema0, _Schema0, _Schema0, _Schema0, _Schema0]
    | [_Schema0, _Schema0, _Schema0, _Schema0, _Schema0, _Schema0]
    | [_Schema0, _Schema0, _Schema0, _Schema0, _Schema0, _Schema0, _Schema0]
    | [_Schema0, _Schema0, _Schema0, _Schema0, _Schema0, _Schema0, _Schema0, _Schema0]
    | [_Schema0, _Schema0, _Schema0, _Schema0, _Schema0, _Schema0, _Schema0, _Schema0, _Schema0]
    | [_Schema0, _Schema0, _Schema0, _Schema0, _Schema0, _Schema0, _Schema0, _Schema0, _Schema0, _Schema0]
    | [_Schema0, _Schema0, _Schema0, _Schema0, _Schema0, _Schema0, _Schema0, _Schema0, _Schema0, _Schema0, _Schema0]
    | [
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0
      ]
    | [
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0
      ]
    | [
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0
      ]
    | [
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0
      ]
    | [
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0
      ]
    | [
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0
      ]
    | [
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0
      ]
    | [
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0
      ]
    | [
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0,
        _Schema0
      ];
  kind: "one_off" | "scheduled" | "recurring" | "triggered" | "api" | "journey";
  category: "marketing" | "lifecycle" | "transactional";
  audience: {
    platforms: _Schema1;
    filters: Audience;
    /**
     * @maxItems 20
     */
    segment_ids:
      | []
      | [_Schema6]
      | [_Schema6, _Schema6]
      | [_Schema6, _Schema6, _Schema6]
      | [_Schema6, _Schema6, _Schema6, _Schema6]
      | [_Schema6, _Schema6, _Schema6, _Schema6, _Schema6]
      | [_Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6]
      | [_Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6]
      | [_Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6]
      | [_Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6]
      | [_Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6]
      | [_Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6]
      | [
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6
        ]
      | [
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6
        ]
      | [
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6
        ]
      | [
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6
        ]
      | [
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6
        ]
      | [
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6
        ]
      | [
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6
        ]
      | [
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6
        ]
      | [
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6
        ];
    /**
     * @maxItems 20
     */
    exclude_segment_ids:
      | []
      | [_Schema6]
      | [_Schema6, _Schema6]
      | [_Schema6, _Schema6, _Schema6]
      | [_Schema6, _Schema6, _Schema6, _Schema6]
      | [_Schema6, _Schema6, _Schema6, _Schema6, _Schema6]
      | [_Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6]
      | [_Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6]
      | [_Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6]
      | [_Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6]
      | [_Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6]
      | [_Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6, _Schema6]
      | [
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6
        ]
      | [
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6
        ]
      | [
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6
        ]
      | [
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6
        ]
      | [
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6
        ]
      | [
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6
        ]
      | [
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6
        ]
      | [
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6
        ]
      | [
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6,
          _Schema6
        ];
    max_audience: number;
  };
  schedule: {
    start_at?: string;
    end_at?: string;
    send_at?: string;
    local_time?: string;
    timezone_fallback: string;
    recurrence?: "daily" | "weekly";
    /**
     * @minItems 1
     * @maxItems 7
     */
    weekdays?:
      | [_Schema7]
      | [_Schema7, _Schema7]
      | [_Schema7, _Schema7, _Schema7]
      | [_Schema7, _Schema7, _Schema7, _Schema7]
      | [_Schema7, _Schema7, _Schema7, _Schema7, _Schema7]
      | [_Schema7, _Schema7, _Schema7, _Schema7, _Schema7, _Schema7]
      | [_Schema7, _Schema7, _Schema7, _Schema7, _Schema7, _Schema7, _Schema7];
  };
  trigger?: {
    event: _Schema0;
    props: _Schema8;
    delay_seconds: number;
  };
  goal?: {
    event: _Schema0;
    props: _Schema8;
    window_hours: number;
    exit_on_goal: boolean;
  };
  experiment: {
    /**
     * @minItems 1
     * @maxItems 8
     */
    arms:
      | [_Schema9]
      | [_Schema9, _Schema9]
      | [_Schema9, _Schema9, _Schema9]
      | [_Schema9, _Schema9, _Schema9, _Schema9]
      | [_Schema9, _Schema9, _Schema9, _Schema9, _Schema9]
      | [_Schema9, _Schema9, _Schema9, _Schema9, _Schema9, _Schema9]
      | [_Schema9, _Schema9, _Schema9, _Schema9, _Schema9, _Schema9, _Schema9]
      | [_Schema9, _Schema9, _Schema9, _Schema9, _Schema9, _Schema9, _Schema9, _Schema9];
    control_pct: number;
  };
  frequency: {
    max_per_user: number;
    min_hours_between: number;
    respect_global_caps: boolean;
  };
  device_policy: "latest_eligible" | "all_eligible";
  priority: number;
  /**
   * @minItems 1
   * @maxItems 30
   */
  messages: [Message, ...Message[]];
  journey?: {
    entry_step: _Schema0;
    /**
     * @minItems 1
     * @maxItems 50
     */
    steps: [_Schema14, ..._Schema14[]];
    max_duration_hours: number;
    reentry_after_hours: number;
  };
  experience?: {
    template: _Schema0;
    content: {
      [k: string]: _Schema16;
    };
    start_at: string;
    end_at: string;
  };
}
export interface _Schema5 {
  [k: string]: PropertyValue;
}
export interface _Schema8 {
  [k: string]: PropertyValue;
}
export interface _Schema9 {
  id: _Schema0;
  weight: number;
}
export interface Message {
  id: _Schema6;
  surface: "push" | "web_push" | "email" | "in_app" | "feed" | "placement";
  target_platforms?: _Schema1;
  placement_id?: _Schema0;
  layout:
    | "standard"
    | "image"
    | "actions"
    | "modal"
    | "slideup"
    | "fullscreen"
    | "sheet"
    | "hero"
    | "banner"
    | "compact"
    | "captioned_image"
    | "image_only"
    | "card"
    | "shell_v1";
  /**
   * @minItems 1
   * @maxItems 8
   */
  variants:
    | [_Schema11]
    | [_Schema11, _Schema11]
    | [_Schema11, _Schema11, _Schema11]
    | [_Schema11, _Schema11, _Schema11, _Schema11]
    | [_Schema11, _Schema11, _Schema11, _Schema11, _Schema11]
    | [_Schema11, _Schema11, _Schema11, _Schema11, _Schema11, _Schema11]
    | [_Schema11, _Schema11, _Schema11, _Schema11, _Schema11, _Schema11, _Schema11]
    | [_Schema11, _Schema11, _Schema11, _Schema11, _Schema11, _Schema11, _Schema11, _Schema11];
  fallback:
    | "skip"
    | {
        layout: "banner" | "compact" | "hero" | "modal" | "standard";
        content: Content;
      };
  trigger?: {
    event: _Schema0;
    props: _Schema8;
  };
  delay_ms: number;
  subject?: string;
  preheader?: string;
  lifecycle_category?: _Schema0;
  ttl_hours: number;
}
export interface _Schema11 {
  id: _Schema0;
  content: Content;
  locales?: {
    [k: string]: Content;
  };
  platform_overrides?: {
    [k: string]: Content;
  };
}
export interface Content {
  title: string;
  body?: string;
  eyebrow?: string;
  badge?: string;
  icon?: {
    key: _Schema0;
  };
  image?: {
    asset_id: _Schema6;
    alt?: string;
    decorative?: boolean;
    aspect: "16:9" | "1:1" | "4:5" | "9:16";
  };
  theme: string;
  primary?: _Schema13;
  secondary?: _Schema13;
  footnote?: string;
  dismissible: boolean;
  abort_if_missing: boolean;
  countdown?: {
    to: string;
    label?: string;
    hide_after: boolean;
  };
}
export interface _Schema13 {
  label: string;
  action: Action;
  style?: "primary" | "secondary" | "link";
}
export interface _Schema51 {
  [k: string]: PropertyValue;
}
export interface _Schema15 {
  weight: number;
  next: _Schema0;
}
