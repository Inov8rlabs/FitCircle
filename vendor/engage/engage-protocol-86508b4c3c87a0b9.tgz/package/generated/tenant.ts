/* Generated from protocol/src/schemas.ts. Do not edit. */

export interface Tenant {
  app_id: string;
  environment: "development" | "test" | "staging" | "production";
}
