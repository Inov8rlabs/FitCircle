/* Generated from protocol/src/schemas.ts. Do not edit. */

export interface WebPushBinding {
  app_id: string;
  environment: "development" | "test" | "staging" | "production";
  install_id: string;
  binding_id: string;
}
