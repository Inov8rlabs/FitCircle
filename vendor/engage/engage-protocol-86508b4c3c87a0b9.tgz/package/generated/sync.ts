/* Generated from protocol/src/schemas.ts. Do not edit. */

export type _Schema0 = string;
export type _Schema2 = string;
export type Action =
  | {
      type: "open_screen";
      screen: _Schema0;
      params?: _Schema4;
    }
  | {
      type: "open_url";
      url: string;
    }
  | {
      type: "paywall";
      context: _Schema0;
    }
  | {
      type: "experience";
      slug: _Schema0;
    }
  | {
      type: "join_campaign";
      slug: _Schema0;
    }
  | {
      type: "fitzy";
      prompt?: string;
    }
  | {
      type: "dismiss";
    }
  | {
      type: "invite";
    }
  | {
      type: "start_circle";
    }
  | {
      type: "log_water";
    }
  | {
      type: "enable_notifications";
    };
export type PropertyValue = string | number | boolean | null;

export interface SyncResponse {
  app_id: _Schema0;
  environment: "development" | "test" | "staging" | "production";
  schema: 1;
  fetched_at: string;
  expires_at: string;
  ttl_seconds: number;
  /**
   * @maxItems 20
   */
  in_app:
    | []
    | [DeliveredMessage]
    | [DeliveredMessage, DeliveredMessage]
    | [DeliveredMessage, DeliveredMessage, DeliveredMessage]
    | [DeliveredMessage, DeliveredMessage, DeliveredMessage, DeliveredMessage]
    | [DeliveredMessage, DeliveredMessage, DeliveredMessage, DeliveredMessage, DeliveredMessage]
    | [DeliveredMessage, DeliveredMessage, DeliveredMessage, DeliveredMessage, DeliveredMessage, DeliveredMessage]
    | [
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage
      ]
    | [
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage
      ]
    | [
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage
      ]
    | [
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage
      ]
    | [
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage
      ]
    | [
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage
      ]
    | [
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage
      ]
    | [
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage
      ]
    | [
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage
      ]
    | [
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage
      ]
    | [
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage
      ]
    | [
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage
      ]
    | [
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage
      ]
    | [
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage,
        DeliveredMessage
      ];
  placements: {
    /**
     * @maxItems 20
     */
    [k: string]:
      | []
      | [DeliveredMessage]
      | [DeliveredMessage, DeliveredMessage]
      | [DeliveredMessage, DeliveredMessage, DeliveredMessage]
      | [DeliveredMessage, DeliveredMessage, DeliveredMessage, DeliveredMessage]
      | [DeliveredMessage, DeliveredMessage, DeliveredMessage, DeliveredMessage, DeliveredMessage]
      | [DeliveredMessage, DeliveredMessage, DeliveredMessage, DeliveredMessage, DeliveredMessage, DeliveredMessage]
      | [
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage
        ]
      | [
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage
        ]
      | [
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage
        ]
      | [
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage
        ]
      | [
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage
        ]
      | [
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage
        ]
      | [
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage
        ]
      | [
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage
        ]
      | [
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage
        ]
      | [
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage
        ]
      | [
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage
        ]
      | [
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage
        ]
      | [
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage
        ]
      | [
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage,
          DeliveredMessage
        ];
  };
  /**
   * @maxItems 3
   */
  feed:
    | []
    | [DeliveredMessage]
    | [DeliveredMessage, DeliveredMessage]
    | [DeliveredMessage, DeliveredMessage, DeliveredMessage];
  assets: {
    [k: string]: {
      url: string;
      mime: string;
      width: number;
      height: number;
    };
  };
  caps: {
    iam_daily: number;
    iam_session: number;
    iam_min_interval_s: number;
  };
}
export interface DeliveredMessage {
  receipt_id: _Schema2;
  campaign_id: _Schema2;
  message_id: _Schema2;
  version: number;
  variant_id: _Schema0;
  surface: "push" | "web_push" | "email" | "in_app" | "feed" | "placement";
  layout: string;
  content: Content;
  priority: number;
  expires_at: string;
  placement_id?: _Schema0;
  trigger?: {
    event: _Schema0;
    props: _Schema41;
  };
  delay_ms: number;
  preview?: boolean;
}
export interface Content {
  title: string;
  body?: string;
  eyebrow?: string;
  badge?: string;
  icon?: {
    key: _Schema0;
  };
  image?: {
    asset_id: _Schema2;
    alt?: string;
    decorative?: boolean;
    aspect: "16:9" | "1:1" | "4:5" | "9:16";
  };
  theme: string;
  primary?: _Schema3;
  secondary?: _Schema3;
  footnote?: string;
  dismissible: boolean;
  abort_if_missing: boolean;
  countdown?: {
    to: string;
    label?: string;
    hide_after: boolean;
  };
}
export interface _Schema3 {
  label: string;
  action: Action;
  style?: "primary" | "secondary" | "link";
}
export interface _Schema4 {
  [k: string]: PropertyValue;
}
export interface _Schema41 {
  [k: string]: PropertyValue;
}
