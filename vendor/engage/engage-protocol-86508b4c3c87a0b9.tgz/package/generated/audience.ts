/* Generated from protocol/src/schemas.ts. Do not edit. */

export type Audience =
  | {
      field: string;
      op:
        | "eq"
        | "neq"
        | "in"
        | "not_in"
        | "gt"
        | "gte"
        | "lt"
        | "lte"
        | "between"
        | "exists"
        | "not_exists"
        | "contains"
        | "version_gte"
        | "version_lt"
        | "version_between"
        | "within_last"
        | "not_within_last"
        | "count_gte"
        | "count_lte";
      value?: string | number | boolean | null | _Schema0[];
      event?: {
        name: string;
        window_seconds: number;
        props: {
          [k: string]: PropertyValue;
        };
      };
    }
  | {
      /**
       * @maxItems 50
       */
      all: Audience[];
    }
  | {
      /**
       * @maxItems 50
       */
      any: Audience[];
    }
  | {
      not: Audience;
    }
  | {
      device: {
        scope: "any_device" | "latest_device";
        where: Audience;
      };
    };
export type _Schema0 = string | number;
export type PropertyValue = string | number | boolean | null;
