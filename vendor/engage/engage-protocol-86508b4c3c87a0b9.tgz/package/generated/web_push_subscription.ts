/* Generated from protocol/src/schemas.ts. Do not edit. */

export interface WebPushSubscription {
  endpoint: string;
  expirationTime?: number | null;
  keys: {
    p256dh: string;
    auth: string;
  };
}
