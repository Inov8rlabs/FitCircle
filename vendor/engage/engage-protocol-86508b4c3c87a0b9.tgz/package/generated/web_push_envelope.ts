/* Generated from protocol/src/schemas.ts. Do not edit. */

export type _Schema0 = string;
export type _Schema1 = string;
export type Action =
  | {
      type: "open_screen";
      screen: _Schema0;
      params?: {
        [k: string]: PropertyValue;
      };
    }
  | {
      type: "open_url";
      url: string;
    }
  | {
      type: "paywall";
      context: _Schema0;
    }
  | {
      type: "experience";
      slug: _Schema0;
    }
  | {
      type: "join_campaign";
      slug: _Schema0;
    }
  | {
      type: "fitzy";
      prompt?: string;
    }
  | {
      type: "dismiss";
    }
  | {
      type: "invite";
    }
  | {
      type: "start_circle";
    }
  | {
      type: "log_water";
    }
  | {
      type: "enable_notifications";
    };
export type PropertyValue = string | number | boolean | null;

export interface WebPushEnvelope {
  app_id: _Schema0;
  environment: "development" | "test" | "staging" | "production";
  install_id: _Schema1;
  binding_id: string;
  schema: 1;
  send_id: _Schema1;
  attempt_id: _Schema1;
  expires_at: string;
  title: string;
  body?: string;
  image?: string;
  /**
   * @maxItems 2
   */
  buttons: [] | [_Schema2] | [_Schema2, _Schema2];
}
export interface _Schema2 {
  label: string;
  action: Action;
}
