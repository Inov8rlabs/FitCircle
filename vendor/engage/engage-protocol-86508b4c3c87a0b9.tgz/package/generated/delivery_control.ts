/* Generated from protocol/src/schemas.ts. Do not edit. */

export interface DeliveryControl {
  campaign_id?: string;
  platform?: "ios" | "android" | "web";
  channel?: "push" | "web_push" | "email" | "in_app" | "feed" | "placement";
  paused: boolean;
  reason: string;
  expected_revision: number;
}
