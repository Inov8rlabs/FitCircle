/* Generated from protocol/src/schemas.ts. Do not edit. */

export type _Schema0 = string;
export type PropertyValue = string | number | boolean | null;

export interface Events {
  install_id: _Schema0;
  /**
   * @minItems 1
   * @maxItems 50
   */
  events: [_Schema1, ..._Schema1[]];
}
export interface _Schema1 {
  client_event_id: _Schema0;
  type: "impression" | "click" | "dismiss" | "push_opened" | "app_event" | "trigger_fired" | "preview_received";
  receipt_id?: _Schema0;
  send_id?: _Schema0;
  permit_id?: _Schema0;
  name?: string;
  props: {
    [k: string]: PropertyValue;
  };
  occurred_at: string;
}
