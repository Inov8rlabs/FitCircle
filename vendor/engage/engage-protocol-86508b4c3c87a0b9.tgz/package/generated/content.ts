/* Generated from protocol/src/schemas.ts. Do not edit. */

export type _Schema0 = string;
export type Action =
  | {
      type: "open_screen";
      screen: _Schema0;
      params?: {
        [k: string]: PropertyValue;
      };
    }
  | {
      type: "open_url";
      url: string;
    }
  | {
      type: "paywall";
      context: _Schema0;
    }
  | {
      type: "experience";
      slug: _Schema0;
    }
  | {
      type: "join_campaign";
      slug: _Schema0;
    }
  | {
      type: "fitzy";
      prompt?: string;
    }
  | {
      type: "dismiss";
    }
  | {
      type: "invite";
    }
  | {
      type: "start_circle";
    }
  | {
      type: "log_water";
    }
  | {
      type: "enable_notifications";
    };
export type PropertyValue = string | number | boolean | null;

export interface Content {
  title: string;
  body?: string;
  eyebrow?: string;
  badge?: string;
  icon?: {
    key: _Schema0;
  };
  image?: {
    asset_id: string;
    alt?: string;
    decorative?: boolean;
    aspect: "16:9" | "1:1" | "4:5" | "9:16";
  };
  theme: string;
  primary?: _Schema1;
  secondary?: _Schema1;
  footnote?: string;
  dismissible: boolean;
  abort_if_missing: boolean;
  countdown?: {
    to: string;
    label?: string;
    hide_after: boolean;
  };
}
export interface _Schema1 {
  label: string;
  action: Action;
  style?: "primary" | "secondary" | "link";
}
