/* Generated from protocol/src/schemas.ts. Do not edit. */

export type _Schema0 = string;
export type _Schema1 = "ios" | "android" | "web";
export type _Schema2 = string;
export type Action =
  | {
      type: "open_screen";
      screen: _Schema2;
      params?: _Schema6;
    }
  | {
      type: "open_url";
      url: string;
    }
  | {
      type: "paywall";
      context: _Schema2;
    }
  | {
      type: "experience";
      slug: _Schema2;
    }
  | {
      type: "join_campaign";
      slug: _Schema2;
    }
  | {
      type: "fitzy";
      prompt?: string;
    }
  | {
      type: "dismiss";
    }
  | {
      type: "invite";
    }
  | {
      type: "start_circle";
    }
  | {
      type: "log_water";
    }
  | {
      type: "enable_notifications";
    };
export type PropertyValue = string | number | boolean | null;

export interface Message {
  id: _Schema0;
  surface: "push" | "web_push" | "email" | "in_app" | "feed" | "placement";
  /**
   * @minItems 1
   * @maxItems 3
   */
  target_platforms?: [_Schema1] | [_Schema1, _Schema1] | [_Schema1, _Schema1, _Schema1];
  placement_id?: _Schema2;
  layout:
    | "standard"
    | "image"
    | "actions"
    | "modal"
    | "slideup"
    | "fullscreen"
    | "sheet"
    | "hero"
    | "banner"
    | "compact"
    | "captioned_image"
    | "image_only"
    | "card"
    | "shell_v1";
  /**
   * @minItems 1
   * @maxItems 8
   */
  variants:
    | [_Schema3]
    | [_Schema3, _Schema3]
    | [_Schema3, _Schema3, _Schema3]
    | [_Schema3, _Schema3, _Schema3, _Schema3]
    | [_Schema3, _Schema3, _Schema3, _Schema3, _Schema3]
    | [_Schema3, _Schema3, _Schema3, _Schema3, _Schema3, _Schema3]
    | [_Schema3, _Schema3, _Schema3, _Schema3, _Schema3, _Schema3, _Schema3]
    | [_Schema3, _Schema3, _Schema3, _Schema3, _Schema3, _Schema3, _Schema3, _Schema3];
  fallback:
    | "skip"
    | {
        layout: "banner" | "compact" | "hero" | "modal" | "standard";
        content: Content;
      };
  trigger?: {
    event: _Schema2;
    props: _Schema61;
  };
  delay_ms: number;
  subject?: string;
  preheader?: string;
  lifecycle_category?: _Schema2;
  ttl_hours: number;
}
export interface _Schema3 {
  id: _Schema2;
  content: Content;
  locales?: {
    [k: string]: Content;
  };
  platform_overrides?: {
    [k: string]: Content;
  };
}
export interface Content {
  title: string;
  body?: string;
  eyebrow?: string;
  badge?: string;
  icon?: {
    key: _Schema2;
  };
  image?: {
    asset_id: _Schema0;
    alt?: string;
    decorative?: boolean;
    aspect: "16:9" | "1:1" | "4:5" | "9:16";
  };
  theme: string;
  primary?: _Schema5;
  secondary?: _Schema5;
  footnote?: string;
  dismissible: boolean;
  abort_if_missing: boolean;
  countdown?: {
    to: string;
    label?: string;
    hide_after: boolean;
  };
}
export interface _Schema5 {
  label: string;
  action: Action;
  style?: "primary" | "secondary" | "link";
}
export interface _Schema6 {
  [k: string]: PropertyValue;
}
export interface _Schema61 {
  [k: string]: PropertyValue;
}
