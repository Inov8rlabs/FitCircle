/* Generated from protocol/src/schemas.ts. Do not edit. */

export type _Schema0 = string;
export type _Schema1 = string;
export type _Schema2 = string;

export interface DeviceSession {
  install_id: string;
  platform: "ios" | "android" | "web";
  app_version: string;
  app_build?: string;
  os_version?: string;
  locale: string;
  timezone: string;
  push_permission: "granted" | "provisional" | "denied" | "not_determined";
  /**
   * @maxItems 40
   */
  layouts: _Schema0[];
  /**
   * @maxItems 40
   */
  actions: _Schema1[];
  /**
   * @maxItems 40
   */
  placements: _Schema2[];
}
