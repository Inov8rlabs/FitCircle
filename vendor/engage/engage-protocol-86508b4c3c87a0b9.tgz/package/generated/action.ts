/* Generated from protocol/src/schemas.ts. Do not edit. */

export type Action =
  | {
      type: "open_screen";
      screen: _Schema0;
      params?: {
        [k: string]: PropertyValue;
      };
    }
  | {
      type: "open_url";
      url: string;
    }
  | {
      type: "paywall";
      context: _Schema0;
    }
  | {
      type: "experience";
      slug: _Schema0;
    }
  | {
      type: "join_campaign";
      slug: _Schema0;
    }
  | {
      type: "fitzy";
      prompt?: string;
    }
  | {
      type: "dismiss";
    }
  | {
      type: "invite";
    }
  | {
      type: "start_circle";
    }
  | {
      type: "log_water";
    }
  | {
      type: "enable_notifications";
    };
export type _Schema0 = string;
export type PropertyValue = string | number | boolean | null;
