-- Thin application-owned delivery metadata. No Engage campaign/core tables.
create schema if not exists engage_connector;
revoke all on schema engage_connector from public;
create table engage_connector.identity (
  singleton boolean primary key default true check(singleton), app_id text not null, environment text not null
);
create table engage_connector.migrations(version integer primary key,checksum text not null,applied_at timestamptz not null default now());
create table engage_connector.subjects (
  user_id uuid primary key, version bigint not null default 0, deleted boolean not null default false
);
create table engage_connector.outbox (
  id bigint generated always as identity primary key, user_id uuid, operation text not null, policy_key text,
  ciphertext text, state text not null default 'pending' check(state in ('pending','leased','done','parked')),
  attempts integer not null default 0, next_attempt_at timestamptz not null default now(),
  lease uuid, lease_until timestamptz, error_code text, created_at timestamptz not null default now(), finished_at timestamptz
);
create index outbox_pending on engage_connector.outbox(next_attempt_at,id) where state in ('pending','leased');
create index outbox_subject on engage_connector.outbox(user_id,id) where state<>'done';
create table engage_connector.checkpoints (name text primary key, cursor bigint not null default 0);
create table engage_connector.nonces (nonce uuid primary key,expires_at timestamptz not null);
revoke all on all tables in schema engage_connector from public;
revoke all on all sequences in schema engage_connector from public;
do $$ declare exposed text; begin
  foreach exposed in array array['anon','authenticated','service_role'] loop
    if exists(select 1 from pg_roles where rolname=exposed) then
      execute format('revoke all on schema engage_connector from %I',exposed);
      execute format('revoke all on all tables in schema engage_connector from %I',exposed);
      execute format('revoke all on all sequences in schema engage_connector from %I',exposed);
      execute format('revoke all on all functions in schema engage_connector from %I',exposed);
    end if;
  end loop;
end $$;
